const cash_out_btn = document.getElementById("cash_out_btn");

cash_out_btn.addEventListener("click", function (e) {
  e.preventDefault();

  const agent_number = document.getElementById("agent_number");
  const subtracted_amount = document.getElementById("subtracted_amount");
  const enteredPin = document.getElementById("add-pin").value.trim();
  const savedPin = localStorage.getItem("userPin");

  if (enteredPin !== savedPin) {
    alert("you are giving a wrong pin");
    return;
  }

  const availableBalanceElement = document.getElementById("available-Balance");
  const availableBalance = parseInt(availableBalanceElement.innerText);

  if (agent_number.length !== 11) {
    alert("give valid agent number");
    return;
  }

  const subtractTotalBalance = availableBalance - subtracted_amount;

  const updatedBalance =
    availableBalanceElement.innerText(subtractTotalBalance);

  if (updatedBalance) {
    alert("your money is out of cash");
  }

  localStorage.setItem("balance", subtractTotalBalance);
});

window.addEventListener("load", function () {
  const availableBalanceElement = document.getElementById("available-Balance");
  const savedBalance = localStorage.getItem("balance");
  if (savedBalance) {
    availableBalanceElement.innerText = savedBalance;
  }
});
